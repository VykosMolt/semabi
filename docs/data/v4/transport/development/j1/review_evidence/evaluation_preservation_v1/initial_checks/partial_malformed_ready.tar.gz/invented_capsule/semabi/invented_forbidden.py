raise AssertionError('Native imports forbidden')

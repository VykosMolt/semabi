"""Invented fixture custody reader; no native imports."""
import hashlib
import importlib.util
from pathlib import Path
spec = importlib.util.spec_from_file_location("_invented_io", Path(__file__).with_name("live_io.py"))
io = importlib.util.module_from_spec(spec)
spec.loader.exec_module(io)
def sha(file): return hashlib.sha256(Path(file).read_bytes()).hexdigest()
def read_json(file): return io.parse_json(Path(file).read_bytes())
def same(left, right): return io.json_bytes(left) == io.json_bytes(right)
def reference(file): return {"path": str(file), "sha256": sha(file)}
